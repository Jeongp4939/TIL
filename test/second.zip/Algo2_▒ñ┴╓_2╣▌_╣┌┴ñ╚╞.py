# 문제 2. 탐사 로봇
# 방향 우,하,좌,상(0,1,2,3)
# 로봇의 진행은 0,0 부터 진행
# 지나간 구역은 다시 지나지 않음
# 방향이 같으면 중복해서 출력하지 않음

dy,dx = [0,1,0,-1],[1,0,-1,0]                       # 방향배열 우 하 좌 상

for tc in range(1,int(input())+1):

    N = int(input())                                # 배열의 크기 N*N

    arr = [list(map(int,input().split())) for _ in range(N)]    # 탐사지역 배열 입력
    visited = [[0]*N for _ in range(N)]             # 지나간 곳을 체크하는 visited 배열
    path = [arr[0][0]]                              # 0,0 에서 시작하므로 arr[0][0]값 추가

    stack = [[0,0]]
    while stack:
        y,x = stack.pop()
        visited[y][x]=1                             # 현재 위치 방문 배열에 체크
        # 배열 현재 좌표의 값이 곧 이동 방향, 현재 좌표에 해당 방향값을 더해줌(좌표이동)
        ny = y + dy[arr[y][x]]
        nx = x + dx[arr[y][x]]
        if 0<=ny<N and 0<=nx<N and visited[ny][nx]==0:  # 방문한 곳이 아니고 범위 안에 있을 시 진행
            if path[-1]!=arr[ny][nx]:               # 방향이 다를 때 경로에 추가
                path.append(arr[ny][nx])
                stack.append([ny,nx])
            elif path[-1]==arr[ny][nx]:             # 방향이 같으면 경로에 추가하지 않고 진행
                stack.append([ny,nx])
    print(f'#{tc}',*path)