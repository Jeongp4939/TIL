# 문제 1. 봉우리의 수
# NxN 개의 구역에 대한 높이정보
# 주변 8개 지역보다 높으면 봉우리
# 봉우리의 가장 높은 곳과 낮은 곳의 높이 차이 출력(봉우리 자체 높이)
# 가장자리 구역은 무시(8개로 둘러쌓인 부분만 검사)
# 봉우리가 하나만 있거나 없는 경우, 높이 차는 -1로 표시

dy=[1,-1,0,0,1,1,-1,-1]
dx=[0,0,-1,1,1,-1,1,-1]

def is_top(y,x):        # 봉우리인지 검사하는 함수
    cnt = 0
    for d in range(8):
        ny = y + dy[d]
        nx = x + dx[d]
        if 0<=ny<N and 0<=nx<N:     # 범위 안에 있을 시 진행(밖에서 범위를 조절해서 없어도 되는 조건문)
            if M[y][x] > M[ny][nx]: # 해당 지역보다 높으면 cnt++
                cnt+=1
    if cnt == 8:                    # 주변 8지역 보다 높으면 1을 리턴
        return 1
    return 0                        # 아니면 0을 리턴

for tc in range(1, int(input())+1):

    N=int(input())
    cnt = 0         # 봉우리 개수
    Max = 0         # 봉우리 최대 높이를 저장할 변수
    Min = 100       # 0<=h<10 이므로 10보다 큰 높이 x

    M = [list(map(int,input().split())) for _ in range(N)]

    for i in range(1,N-1):              # 가장자리들을 제외한 배열들을 전부 순회
        for j in range(1,N-1):
            if is_top(i,j):             # 함수 호출
                cnt+=1                  # 봉우리가 맞으면 cnt++, 아래 조건문 실행
                if M[i][j] > Max:       # 봉우리의 높이가 Max 보다 높으면 Max에 저장
                    Max = M[i][j]
                if M[i][j] < Min:       # 봉우리의 높이가 Min 보다 낮으면 Min에 저장
                    Min = M[i][j]
    if cnt<=1:                          # 봉우리 수가 한 개이거나 없으면 -1
        print(f'#{tc} -1')
    else:                               # 봉우리가 2개 이상인 경우 Max-Min
        print(f'#{tc} {Max-Min}')


